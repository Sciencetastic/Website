NES-compliant backgrounds (93)
==============================
backgrounds/        the finished PNGs. UI screens are the 112x112 viewport; full-screen art keeps its size.
attribute_tables/   per image: <name>.attr.bin (64-byte NES attribute table, palette 0-3 = group 1-4 per 16x16 square)
                    and <name>.palettes.json (the four palettes + backdrop).
audit_summary.csv   result of the NES Auditor on every file (palette rules, groups, tile patterns, how it was made).
contact_sheet.png   overview.  green tick = your approved file, copied untouched;  ~ = colours taken from the original art's
                    palette (no pixel alignment - the roughest group, review these first);  * = theme colours, no reference.

Rules every file meets: black backdrop + at most 3 colours per 16x16 square, at most 4 palette groups.
Tile budget: all but your approved burnt_bedroom (193 incl. the blank tile) are at or under 192 unique 8x8 patterns;
19 of mine were trimmed by 1-26 pixels to get there.

Approved by you (untouched): alchemist_house, alchemist_house_door_open, Angular_Death_1, Barn, burnt_bedroom.
Roughest group (~ or *): alchemist_house, alchemist_house_door_open, Angular_Death_1, black, Black_BG, Cellar_Candle_Death, CU1, CU4, CU5, Face_Eaten, Fall_Backswitch, Forest_Cave_Death_F1, Forest_Cave_Death_f2, Forest_Cave_Death_F3, Gameboy Graphic, Inventory UI_Blank, Inventory UI_Diary_Page, Inventory UI_FOLIO_Journal_Select, Inventory UI_FOLIO_select_blank, Inventory UI_KEYS_select_blank, Inventory UI_LARGE_select, Inventory UI_LARGE_select2, Inventory UI_Notes_Select, Inventory UI_SMALL_select_blank, Inventory UI_TOOLS_select_blank, logo, Market_Place_Death, Mine_Death, Mine_Temple_Flame_death, Opening_1, Opening_2, Opening_3, Opening_4, Opening_5, tentacle_Death, titlescreen, Village_Black_Smith, Village_Work_Bench, VillageValley, wolf_bite
