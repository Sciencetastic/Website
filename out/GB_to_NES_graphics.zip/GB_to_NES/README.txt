GB -> NES colorization
======================
graphics/                 93 screens (112x112 viewport crops for UI screens, full size for others)
graphics/sprites_icons/   59 sprites/icons (report.json = method + palette per file)
scene_report.json         method per screen
nes_audit_summary.csv     result of your audit_filter_draft2.py on every screen:
                          palette pass (93/93, shared BLACK backdrop), unique 8x8 pattern lower bound vs 192-tile budget
*_contact_sheet.png       overview; ~ = reference palette, * = theme fallback
Rule: every 16x16 block = shared black backdrop + <=3 colours, <=4 palette groups per image.
Not touched: npc004-006 (already coloured), black/Black_BG, Gameboy Graphic.
tools/ = Python scripts (Python 3 + Pillow + numpy); tools/art_eval = your audit scripts.
