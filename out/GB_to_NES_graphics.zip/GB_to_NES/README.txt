GB -> NES colorization, first pass
===================================
graphics/                 93 screens (112x112 viewport crops for UI screens, full size for others)
graphics/sprites_icons/   59 sprites/icons (report.json = method + palette per file)
scene_report.json         method per screen: B_direct (fit to matched original),
                          A_gb_structure, reference_palette (~ on sheet), theme_fallback
*_contact_sheet.png       overview of everything; ~ = reference palette, * = theme fallback

Rule used: every 16x16 block = shared backdrop + at most 3 colours, max 4 palettes per image.
Not touched: npc004-006 (already coloured, not NES-compliant), black/Black_BG, Gameboy Graphic.
tools/ = the Python scripts (need Python 3 + Pillow + numpy).
